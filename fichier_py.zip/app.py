# app.py
# ============================================================
# Streamlit HUB (app principale)
# - Point d'entrée pour Streamlit.io
# - Affiche un menu latéral (étude de marché / site démo)
# - Appelle des modules séparés dans src/
#
# IMPORTANT :
# - Ne lance PAS les scripts offline (traitement_db.py / build_ml_ready.py)
# - L'app consomme uniquement les CSV déjà présents dans data/
# ============================================================

import streamlit as st


# -----------------------------
# Config Streamlit
# -----------------------------
st.set_page_config(
    page_title="Projet 2 — Cinéma Creuse",
    layout="wide",
)

# -----------------------------
# Imports des pages (modules)
# -----------------------------
# NOTE : Ces fichiers doivent exister dans src/
# - src/market_app.py  -> render_market()
# - src/site_app.py    -> render_site()
#
# Pour l'instant, si tu n'as pas encore créé ces modules,
# tu peux laisser les imports commentés et utiliser les placeholders plus bas.
try:
    from src.market_app import render_market
except Exception:
    render_market = None

try:
    from src.site_app import render_site
except Exception:
    render_site = None


# -----------------------------
# UI — Sidebar
# -----------------------------
st.sidebar.title("Projet 2 — Hub")

section = st.sidebar.radio(
    "Navigation",
    [
        "Étude de marché",
        "Site (démo + reco)",
        "DB / Notes",
    ],
    index=0,
)

st.sidebar.markdown("---")

# Optionnel : petit indicateur de statut
st.sidebar.caption("Données ML : data/imdb/out/ml_ready/")
st.sidebar.caption("Données marché : data/INSEE/ + data/CNC/")


# -----------------------------
# Contenu principal
# -----------------------------
if section == "Étude de marché":
    st.title("Étude de marché — Creuse")
    st.caption("Visualisations INSEE + CNC (module séparé).")

    if render_market is None:
        st.warning(
            "Module `src/market_app.py` introuvable ou en erreur.\n\n"
            "Crée `src/market_app.py` avec une fonction `render_market()`."
        )
        st.code(
            "def render_market():\n"
            "    import streamlit as st\n"
            "    st.write('Market app placeholder')\n",
            language="python",
        )
    else:
        render_market()

elif section == "Site (démo + reco)":
    st.title("Site — Démo + Recommandations")
    st.caption("Recherche film/personne + recommandations + page film (module séparé).")

    if render_site is None:
        st.warning(
            "Module `src/site_app.py` introuvable ou en erreur.\n\n"
            "Crée `src/site_app.py` avec une fonction `render_site()`."
        )
        st.code(
            "def render_site():\n"
            "    import streamlit as st\n"
            "    st.write('Site app placeholder')\n",
            language="python",
        )
    else:
        render_site()

else:  # "DB / Notes"
    st.title("DB / Notes")
    st.info(
        "Espace libre pour expliquer ton pipeline (IMDb -> parts -> ml_ready) "
        "et documenter ce que tu as fait."
    )

    st.markdown(
        """
### Pipeline (résumé)
- **Scripts offline** (à lancer en local uniquement) :
  - `data/imdb/traitement_db.py` → génère `data/imdb/out/films/part_*.csv` + `data/imdb/out/credits/part_*.csv`
  - `data/imdb/build_ml_ready.py` → génère `data/imdb/out/ml_ready/films_ml/part_*.csv` + `person_index.csv`

- **App Streamlit (Streamlit.io)** :
  - Charge uniquement les fichiers dans `data/` (déjà présents dans le repo)
  - Construit le modèle TF-IDF/KNN en mémoire avec cache Streamlit
        """
    )
